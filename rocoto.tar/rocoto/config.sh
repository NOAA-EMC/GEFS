sed -e "s/sYYYYMMDDHH/2018032918/"               \
    -e "s/eYYYYMMDDHH/2018032918/"               \
    -e "s/TEST/tgBj/"                            \
    -e "s/HPS_PTMP/hps/"                              \
    -e "s/First/Dingchen/"                       \
    -e "s/Last/Hou/"                             \
    user.conf_protype                            \
    > user.conf
